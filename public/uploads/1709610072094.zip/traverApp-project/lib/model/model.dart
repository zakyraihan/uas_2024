import 'dart:convert';

part 'forgot_password.dart';
part 'kategori.dart';
part 'login.dart';
part 'pagination.dart';
part 'register.dart';
part 'wisata.dart';
